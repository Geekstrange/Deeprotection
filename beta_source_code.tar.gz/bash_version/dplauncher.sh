#!/bin/bash
# Copyright (c) 2025 Shuaibo Zhang
# shellcheck disable=SC2154,SC1090,SC1091

CONFIG_FILE="/etc/deeprotection/deeprotection.conf"
LANGUAGE_PATH="/usr/share/locale/deeprotection/"
CONFIG_DIR="${CONFIG_FILE%/*}"

# 解析FTL文件的函数
parse_ftl() {
    local file="$1"
    while IFS= read -r line; do
        # 跳过空行和注释行
        [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue

        # 解析键值对
        if [[ "$line" =~ ^([[:alnum:]_]+)[[:space:]]*=[[:space:]]*\"(.*)\"$ ]]; then
            key="${BASH_REMATCH[1]}"
            value="${BASH_REMATCH[2]}"
            # 替换转义字符
            value=${value//\\\"/\"}
            value=${value//\\n/$'\n'}
            # 设置变量
            declare -g "$key=\"$value\""
        fi
    done < "$file"
}

call_dploader() {
    $(which dploader)
}

get_language_value() {
    language_val=$(awk -F= '/^[[:space:]]*language[[:space:]]*=/ {
        sub(/#.*/, "", $2);
        gsub(/[ \t]/, "", $2);
        print $2
    }' "$CONFIG_FILE")
}
get_language_value
update_language() {
    local new_lang="$1"
    sed -i "s/^[[:space:]]*language[[:space:]]*=.*/language=$new_lang/" "$CONFIG_FILE"
}

manual_language_setup() {
    # 确保变量有默认值
    local msg_select_language=${msg_select_language:-"Available languages"}
    local err_no_lang_files=${err_no_lang_files:-"Error: No language files found"}
    local msg_lang_support=${msg_lang_support:-"Appreciate if you could provide language support"}
    local msg_select_option=${msg_select_option:-"Select option"}
    local err_invalid_selection=${err_invalid_selection:-"Invalid selection"}

    echo -e "\n$msg_select_language:"

    # 检测所有可用的语言文件
    lang_files=("$LANGUAGE_PATH"/*.ftl)
    if (( ${#lang_files[@]} == 0 )); then
        echo "$err_no_lang_files" >&2
        exit 1
    fi

    # 显示语言列表
    local i=1
    declare -a lang_codes
    declare -a lang_names

    for file in "${lang_files[@]}"; do
        # 提取文件名（不含路径和扩展名）
        lang_code=$(basename "$file" .ftl)
        lang_codes[i]="$lang_code"

        # 临时解析文件获取语言名称
        local tmp_name=$(awk -F= '/^name[[:space:]]*=/ {
            gsub(/^[" ]+|[" ]+$/, "", $2);
            print $2
        }' "$file" 2>/dev/null)

        # 如果无法提取名称，使用语言代码
        lang_name=${tmp_name:-$lang_code}
        lang_names[i]="$lang_name"

        printf "%2d) %s\n" "$i" "$lang_name"
        ((i++))
    done

    # 添加语言支持提示
    printf '\n%s\n' "$msg_lang_support"
    local lang_count=${#lang_files[@]}

    while true; do
        read -p $'\n'"$msg_select_option (1-$lang_count): " choice

        # 验证输入
        if [[ ! "$choice" =~ ^[0-9]+$ ]] || (( choice < 1 || choice > lang_count )); then
            echo "$err_invalid_selection"
            continue
        fi

        # 获取选择的语言代码
        local selected_code="${lang_codes[$choice]}"
        local selected_file="$LANGUAGE_PATH/${selected_code}.ftl"

        if [[ -f "$selected_file" ]]; then
            update_language "$selected_code"
            parse_ftl "$selected_file"  # 使用解析函数代替source
            echo -e "\n${greet}${name}"
            break
        else
            echo "$err_invalid_selection"
        fi
    done
}

check_language() {
    # 初始化空值校验
    if [[ -z "$language_val" ]]; then
        # 使用 locale 命令获取当前语言
        current_lang=$(echo "${LC_ALL:-${LANG:-en_US}}" | cut -d. -f1 | cut -d'_' -f1)

        # 遍历语言文件目录，查找最佳匹配
        best_match=""
        for lang_file in "$LANGUAGE_PATH"/*.ftl; do
            lang_code=$(basename "$lang_file" .ftl)
            # 检查完全匹配
            if [[ "$lang_code" == "$current_lang" ]]; then
                best_match="$lang_code"
                break
            fi
            # 检查主语言匹配（如 zh_CN 匹配 zh）
            if [[ "$lang_code" =~ ^${current_lang}_ ]] && [[ -z "$best_match" ]]; then
                best_match="$lang_code"
            fi
        done

        # 如果找到匹配的语言文件，询问用户
        if [[ -n "$best_match" ]]; then
            # 临时解析文件获取语言名称
            local tmp_name=$(awk -F= '/^name[[:space:]]*=/ {
                gsub(/^[" ]+|[" ]+$/, "", $2);
                print $2
            }' "$LANGUAGE_PATH/$best_match.ftl" 2>/dev/null)

            # 确保提示变量有默认值
            local msg_confirm_lang=${msg_confirm_lang:-"Is"}

            read -p "$msg_confirm_lang ${tmp_name:-$best_match}? $(printf '(\033[32my\033[0m)es/(\033[31mn\033[0m)o:\n') " answer
            if [[ "$answer" =~ [Yy] ]]; then
                update_language "$best_match"
                parse_ftl "$LANGUAGE_PATH/$best_match.ftl"
                echo "${greet}${name}"
            else
                manual_language_setup
            fi
        else
            manual_language_setup
        fi
    else
        # 直接加载配置的语言文件
        if [[ -f "$LANGUAGE_PATH/$language_val.ftl" ]]; then
            parse_ftl "$LANGUAGE_PATH/$language_val.ftl"
        elif [[ -f "$LANGUAGE_PATH/$language_val" ]]; then
            parse_ftl "$LANGUAGE_PATH/$language_val"
        else
            echo "${err_no_config:-"Error: No valid configuration found"}" >&2
            manual_language_setup
        fi
    fi
}

# Main execution
check_language

#--------------------- 工具函数 ---------------------
check_config() {
    # 强校验目录创建逻辑
    if [ ! -d "$CONFIG_DIR" ]; then
        if ! mkdir -p "$CONFIG_DIR"; then
            echo "${err_create_directory:-"Fatal error: Unable to create directory"} $CONFIG_DIR" >&2
            exit 1
        else
            if ! touch "$CONFIG_FILE"; then
                echo "${err_create_config:-"Fatal error: Unable to create configuration file"} $CONFIG_FILE" >&2
                exit 1
            fi
            printf "${msg_init_complete:-"Configuration initialization complete, please add rules"}: %s\n" "$CONFIG_FILE"
        fi
    fi
    return 0
}

get_disable_value() {
    disable_val=$(awk -F= '/^[[:space:]]*disable[[:space:]]*=/ {
        sub(/#.*/, "", $2);
        gsub(/[ \t]/, "", $2);
        print $2
    }' "$CONFIG_FILE")
}
get_disable_value

get_expire_hours_value() {
    expire_hours=$(awk -F= '/^[[:space:]]*expire_hours[[:space:]]*=/ {
        sub(/#.*/, "", $2);
        gsub(/[ \t]/, "", $2);
        print $2
    }' "$CONFIG_FILE")
}
get_expire_hours_value

get_timestamp_value() {
    timestamp=$(awk -F= '/^[[:space:]]*timestamp[[:space:]]*=/ {
        sub(/#.*/, "", $2);
        gsub(/[ \t]/, "", $2);
        print $2
    }' "$CONFIG_FILE")
}
get_timestamp_value

self_starting_manager() {
    local shell_type=$(basename "$SHELL")
    local config_file="$HOME/.${shell_type}rc"
    local dplauncher_path="$(which dplauncher)"

    if [[ "$1" == "add" ]]; then
        if grep -q "$dplauncher_path" "$config_file"; then
            return 1
        fi
        echo "$dplauncher_path" >> "$config_file"
        source "$config_file"

    elif [[ "$1" == "remove" ]]; then
        sed -i "\|$dplauncher_path|d" "$config_file" 2>/dev/null
        source "$config_file"
    fi
}

#--------------------- 核心逻辑 ---------------------
check_expire() {
    disable_val="${disable_val,,}"

    if [[ "$disable_val" == "true" ]]; then
        self_starting_manager remove
        exit 0
    else
        self_starting_manager add
    fi

    if ! [[ "$expire_hours" =~ ^[0-9]+(\.[0-9]+)?$ ]]; then
        echo " ${err_expire_hours:-"Error: Invalid expire_hours format"}" >&2
        exit 1
    fi

    if [[ "$timestamp" =~ ^[0-9]+$ ]]; then
        local current_ts=$(date +%s)
        local expire_seconds=$(echo "scale=0; ($expire_hours * 3600 + 0.5)/1" | bc)
        local expire_ts=$(echo "$timestamp + $expire_seconds" | bc)

        if (( $(echo "$current_ts < $expire_ts" | bc) )); then
            local remain=$(( expire_ts - current_ts ))
            local hours=$(echo "scale=0; $remain / 3600" | bc)
            local minutes=$(echo "scale=0; ($remain % 3600) / 60" | bc)

            printf " ${msg_remain_time:-"Remaining disable time"}: %02dh %02dmin\n" $hours $minutes
            exit 0
        fi
    fi
}

update_timestamp() {
    local new_ts="$1"
    sed -i "s/^[[:space:]]*timestamp[[:space:]]*=.*/timestamp=$new_ts/" "$CONFIG_FILE"
}

#--------------------- 用户交互 ---------------------
user_interaction() {
    while :; do
        # 确保提示变量有默认值
        local ask_enable_now=${ask_enable_now:-"Do you want to enable the feature now"}
        local msg_skip_this=${msg_skip_this:-"Skip this time"}
        local msg_invalid_input=${msg_invalid_input:-"Invalid input"}
        local msg_temporary_disable=${msg_temporary_disable:-"Temporarily disabled, valid for"}

        read -p "$ask_enable_now? $(printf '(\033[32my\033[0m)es/(\033[31mn\033[0m)o/(\033[33ms\033[0m)kip:\n') " choice
        choice=$(tr '[:upper:]' '[:lower:]' <<< "$choice")

        case "$choice" in
            y)
                update_timestamp "0"
                call_dploader
                exit 0
                ;;
            n)
                update_timestamp "$(date +%s)"
                echo "$msg_temporary_disable $expire_hours h"
                exit 0
                ;;
            s)
                echo "$msg_skip_this"
                exit 0
                ;;
            *)
                echo "$msg_invalid_input"
                ;;
        esac
    done
}

main() {
    check_config
    check_expire
    user_interaction
}

main
