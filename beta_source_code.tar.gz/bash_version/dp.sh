#!/bin/bash
# Copyright (c) 2025 Shuaibo Zhang
# shellcheck disable=SC2154

CONFIG_FILE="/etc/deeprotection/deeprotection.conf"
LANG_DIR="/usr/share/locale/deeprotection"
LOG_FILE="/var/log/deeprotection.log"
LOG_DIR="${LOG_FILE%/*}"
####################################################
####################语言加载模块####################
####################################################
parse_ftl() {
    local file="$1"
    while IFS= read -r line || [[ -n "$line" ]]; do
        # 跳过空行、注释行和无效行
        [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue
        [[ ! "$line" =~ = ]] && continue

        # 提取键和值
        local key="${line%%=*}"
        key="${key//[[:space:]]/}"  # 移除键中的空格

        local value="${line#*=}"
        # 移除值两端的引号（如果存在）
        if [[ "$value" =~ ^\".*\"$ ]]; then
            value="${value:1:-1}"
        fi

        # 处理转义字符
        value="${value//\\\"/\"}"    # 处理转义双引号
        value="${value//\\\\/\\}"    # 处理转义反斜杠
        value="${value//\\n/$'\n'}"  # 处理换行符

        # 设置全局变量
        declare -g "$key"="$value"
    done < "$file"
}

# 加载语言文件的函数 - 可在多个脚本中复用
load_language() {
    local lang_code="$1"
    local ftl_file="${LANG_DIR}/${lang_code}.ftl"
    local default_file="${LANG_DIR}/en_US.ftl"

    # 尝试加载请求的语言
    if [[ -f "$ftl_file" ]]; then
        parse_ftl "$ftl_file"
        return 0
    fi

    # 回退到默认语言
    if [[ -f "$default_file" ]]; then
        parse_ftl "$default_file"
        printf "\033[32mUsing default language.\033[0m\n"
        return 1
    fi

    # 没有可用的语言文件
    printf "\033[31mError: No language files found\033[0m\n"
    return 2
}

get_lang_code() {
    # 直接修改全局变量 lang_code
    lang_code=$(awk -F= '/^[[:space:]]*language[[:space:]]*=/ {
        sub(/#.*/, "", $2);  # 移除值后注释
        gsub(/[ \t]/, "", $2);  # 删除所有空格和制表符
        print $2
    }' "$CONFIG_FILE")
}

# 主语言加载逻辑
get_lang_code
if [[ -z "$lang_code" ]]; then
    # 如果没有配置语言，尝试检测系统语言
    system_lang=$(echo "${LC_ALL:-${LANG:-en_US}}" | cut -d. -f1)
    if [[ -f "${LANG_DIR}/${system_lang}.ftl" ]]; then
        lang_code="$system_lang"
    else
        lang_code="en_US"
    fi
fi

# 加载语言文件
load_language "$lang_code"
####################################################
###################日志初始化模块###################
####################################################
# 初始化日志文件
if [ ! -d "$LOG_DIR" ]; then
    if ! mkdir -p "$LOG_DIR"; then
#        echo "致命错误: 无法创建目录 $LOG_DIR" >&2
        echo "${err_create_directory} ${LOG_DIR}" >&2
        exit 1
    else
        if ! touch "$LOG_FILE"; then
#            echo "致命错误: 无法创建配置文件 $LOG_FILE" >&2
            echo "${err_create_config} ${LOG_FILE}" >&2
            exit 1
  		fi
    fi
fi
####################################################
####################日志记录模块####################
####################################################
output_log() {
    local timestamp user command path
    timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    user=$(whoami)
    path=$(pwd)
    exit_code=$?
    current_pid=$$

    if [ $# -ge 2 ]; then
        command="${@:1:$#-2}"
    else
        command=""
    fi

    echo "${timestamp} | user: ${user} | command: $@ | path: ${path} | current_pid: ${current_pid} | exit_code: ${exit_code}" >> "$LOG_FILE"
}
####################################################
####################命令管道模块####################
####################################################
command_pipeline_module() {
    # 1. 调用路径保护模块
    protected_paths_module "$@"
    local code=$?
    if [[ $code -ne 0 ]]; then
        return $code
    fi

    # 2. 调用命令拦截模块
    command_intercept_module "$@"
    code=$?
    if [[ $code -ne 0 ]]; then
        return $code
    fi

    # 3. 调用删除确认模块
    rm_replace_module "$@"
    return $?
}
pipeline_debug() {
    echo "[DEBUG]: Enter: command_pipeline_module"  # debug output
    protected_paths_module "$@"
    local code=$?
    echo "[DEBUG]: protected_paths_module Return: $code"  # debug output
    if [[ $code -ne 0 ]]; then
        return $code
    fi

    command_intercept_module "$@"
    code=$?
    echo "[DEBUG]: command_intercept_module Return: $code"  # debug output
    if [[ $code -ne 0 ]]; then
        return $code
    fi

    echo "[DEBUG]: Calling: rm_replace_module"  # debug output
    rm_replace_module "$@"
    return $?
}
####################################################
####################路径保护模块####################
####################################################
protected_paths_module() {
    _load_protected_paths() {
        local protected_paths=()
        local in_protected_section=0

        while IFS= read -r line; do
            if [[ "$line" == "#protected_paths_list" ]]; then
                in_protected_section=1
                continue
            elif [[ "$line" == "#"* && $in_protected_section -eq 1 ]]; then
                in_protected_section=0
                break
            fi
            if (( in_protected_section )) && [[ -n "$line" && ! "$line" =~ ^[[:space:]]*# ]]; then
                protected_paths+=("$(realpath -m "$line")")
            fi
        done < "$CONFIG_FILE"
        echo "${protected_paths[@]}"
    }

    _check_protected_paths() {
        local protected_paths=($(_load_protected_paths))

        for arg in "$@"; do
            [[ "$arg" == -* ]] && continue
            local target_path=$(realpath -m "$arg")
            for protected in "${protected_paths[@]}"; do
                if [[ "$target_path" == "$protected"* ]]; then
                    output_log "$@"
#                    echo -e "\a\033[5;31m[!]\033[0m 警告: 禁止操作受保护路径 $protected"
                    echo -e "\a\033[5;31m[!]\033[0m ${war_forbid_path} ${protected}"
                    return 1  # 拦截命令,返回非0状态码
                fi
            done
        done
        return 0  # 未拦截,返回0
    }

    _check_protected_paths "$@"
}
####################################################
####################命令拦截模块####################
####################################################
command_intercept_module() {
    _load_command_intercept_rules() {
        declare -gA command_intercept_rules
        local in_command_section=0
        while IFS= read -r line; do
            if [[ "$line" == "#command_intercept_rules" ]]; then
                in_command_section=1
                continue
            elif [[ "$line" == "#"* && $in_command_section -eq 1 ]]; then
                in_command_section=0
                break
            fi
            if [[ $in_command_section -eq 1 ]]; then
                IFS='>' read -r original_cmd replaced <<< "$line"
                original_cmd=$(_trim "$original_cmd")
                replaced=$(_trim "$replaced")
                command_intercept_rules["$original_cmd"]="$replaced"
            fi
        done < "$CONFIG_FILE"
    }

    _trim() {
        local str="$*"
        str="${str#"${str%%[![:space:]]*}"}"
        str="${str%"${str##*[![:space:]]}"}"
        echo "$str"
    }

    _regex_escape() {
        sed -e 's/[][\.|$(){}?+^]/\\&/g' -e 's/\s\+/\\s*/g' <<< "$*"
    }
	_compare_nu_predict_rmstar() {
		if [[ "$1" != "rm" ]]; then
			if ! command -v "$@" >/dev/null 2>&1; then
				echo "$(which dp)shell: $@: command not found "
			else
				eval "$@"
			fi
			return $?
		fi
		# 紧急修复"rm -rf /*"无法拦截 bug_202505222006
		# 优化后的危险路径检测(版本3.1)
		local danger_patterns=(
			"/"             # 根目录
			"/bin"          # 系统二进制目录
			"/etc"          # 系统配置目录
			"/home"         # 用户主目录
			"/usr"          # 用户程序目录
			"/root"         # root主目录
			"/lib"          # 系统库目录
			"/sbin"         # 系统管理命令
			"/var"          # 可变数据目录
			"/sys"          # 系统信息目录
			"/proc"         # 进程信息目录
			"/dev"          # 设备文件目录
		)

		for arg in "${@:2}"; do
			[[ "$arg" == -* ]] && continue  # 跳过选项参数

			# 标准化路径处理
			local resolved_arg=$(realpath -m "$arg" 2>/dev/null)
			resolved_arg="${resolved_arg%/}"  # 统一去除末尾斜杠

			# 精确匹配保护目录(仅匹配目录本身)
			for pattern in "${danger_patterns[@]}"; do
				# 只匹配完全相等的路径(带或不带斜杠)
				if [[ "$resolved_arg" == "$pattern" || "$resolved_arg" == "$pattern/" ]]; then
					printf "\a\033[5;31m[!]\033[0m ${war_rmstar_block}\n"
					output_log "$*" "${log_rm_suspect}"
					return 1
				fi
			done

			# 增强型通配符检测(仅检测根目录通配符)
			if [[ "$resolved_arg" =~ ^/(\*|\.\*)$ ]]; then
				printf "\a\033[5;31m[!]\033[0m ${war_rmstar_block}\n"
				output_log "$*" "${log_rm_suspect}"
				return 1
			fi
		done

		# 原有*通配符检测逻辑(仅限当前目录)
		local current_files=(*)
		local files=()
		for arg in "${@:2}"; do
			[[ "$arg" != -* ]] && files+=("$arg")
		done

		if [[ ${#files[@]} -eq 0 ]]; then
			eval "$@"
			return "$?"
		fi

		local sorted_args=$(printf "%s\n" "${files[@]}" | sort)
		local sorted_files=$(printf "%s\n" "${current_files[@]}" | sort)
		if [[ "$sorted_args" == "$sorted_files" ]]; then
			printf "\a\033[5;31m[!]\033[0m ${war_rmstar_block}\n"
			output_log "$*" "${log_rm_suspect}"
			return 1
		fi

		# 模式处理逻辑保持不变
		if [[ "${MODE_CONFIG[0]}" == "mode=permissive" ]]; then
			output_log "[rm-permissive] rm ${files[*]}"
			eval "$@"
			return $?
		else
			return 0
		fi
	}
    _command_handle() {
        _load_command_intercept_rules
        local full_cmd="$*"
        local best_match=""
        local best_match_length=0

        for pattern in "${!command_intercept_rules[@]}"; do
            local escaped_pattern=$(_regex_escape "$pattern")
            local regex_pattern="^[[:space:]]*${escaped_pattern}[[:space:]]*$"
            if [[ "$full_cmd" =~ $regex_pattern ]]; then
                if (( ${#pattern} > best_match_length )); then
                    best_match="$pattern"
                    best_match_length=${#pattern}
                fi
            fi
        done

        if [[ -n "$best_match" ]]; then
            local replaced_cmd="${command_intercept_rules[$best_match]}"
            if [[ -z "$replaced_cmd" ]]; then
#                printf "\a\033[5;31m[!]\033[0m 已拦截 %s\n" "$full_cmd"
                printf "\a\033[5;31m[!]\033[0m ${war_rule_match} %s\n" "$full_cmd"
#                output_log "[规则匹配拦截] $full_cmd"
                output_log "[${log_int_blocked}] $full_cmd"
                return 1
            else
#                printf "\a\033[5;31m[!]\033[0m 原始命令: %s → 替换为: %s\n" "$full_cmd" "$replaced_cmd"
                printf "\a\033[5;31m[!]\033[0m ${war_cmd_original}: %s -> ${war_cmd_replace}: %s\n" "$full_cmd" "$replaced_cmd"
                IFS=' ' read -ra log_args <<< "$replaced_cmd"
                output_log "${log_args[@]}"
                _compare_nu_predict_rmstar "${log_args[@]}"
                return $?
            fi
        else
            _compare_nu_predict_rmstar "$@"
            return $?
        fi
    }

    _command_handle "$@"
}
####################################################
####################删除确认模块####################
####################################################
rm_replace_module() {
    # 分离命令名与参数
    local cmd=$1
    shift  # 移除命令名

    # 非 rm 命令直接放行
    if [[ "$cmd" != "rm" ]]; then
#        command "$cmd"
        #exit $?
		return "$?"
    fi

    # 以下为 rm 命令的特殊处理逻辑
    local force_flag=0 recursive_flag=0
    local files=()

    # 解析 rm 的参数
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -f|--force) force_flag=1 ;;
            -r|-R|--recursive) recursive_flag=1 ;;
            -rf*) force_flag=1; recursive_flag=1 ;;
            --) shift; files+=("$@"); break ;; # 处理 -- 后的参数
            -*)
#                echo "警告: 跳过不支持参数 '$1'"
                echo "${war_skip_unsupported} '$1'"
                ;;
            *)
                files+=("$1")
                ;;
        esac
        shift
    done

    # 构建最终参数
    local rm_args=("-i" "-v")
    [ $recursive_flag -eq 1 ] && rm_args+=("-r")
    [ ${#files[@]} -gt 0 ] && rm_args+=("${files[@]}")

    # 执行命令
#    printf "\a\033[5;31m[!]\033[0m 即将执行: /bin/rm %s\n" "${rm_args[*]}"
#    printf "\a\033[5;31m[!]\033[0m ${war_will_execute}: /bin/rm %s\n" "${rm_args[*]}"
    printf '\033[5;33m<!>\033[0m '"${war_will_execute}: /bin/rm %s\n" "${rm_args[*]}"
    /bin/rm "${rm_args[@]}"
	return $?
}
####################################################
####################模式检查模块####################
####################################################
check_mode_module() {
	declare -a MODE_CONFIG=()
	_get_mode_value() {
		mode_val=$(awk -F= '/^[[:space:]]*mode[[:space:]]*=/ {
			sub(/#.*/, "", $2);  # 移除值后注释
			gsub(/[ \t]/, "", $2);  # 删除所有空格和制表符
			print $2
		}' "$CONFIG_FILE")
	}

    _check_mode() {
        _get_mode_value

        if [[ -z "$mode_val" ]]; then
#            echo "错误: 请手动设置模式" >&2
            echo "${err_set_mode}" >&2
            exit 1
        fi

        case "${mode_val,,}" in
            "enhanced")
                if [[ "$mode_val" == "Enhanced" ]]; then
					MODE_CONFIG=( mode=enhanced )
                    command_pipeline_module "$@"
                else
#                    echo "此模式严格区分大小写,请使用Enhanced"
                    echo "${err_use_enhanced}"
                fi
                ;;
            "permissive")
				MODE_CONFIG=( mode=permissive )
                command_intercept_module "$@"
                ;;
            *)
#                echo "未知状态: $mode_val"
                echo "${err_unknown_status}: $mode_val"
                exit 2
                ;;
        esac
    }

    _check_mode "$@"
}
####################################################
#####################伪shell环境####################
####################################################
start_animation() {
	str="dpshell>"
	cols=$(tput cols) # 获取终端宽度
	len=${#str}       # 字符串长度
	tput civis

	# 无颜色移动动画
	for ((i = 0; i <= cols - len; i++)); do
		printf "\r%${i}s%s" " " "$str"
		sleep 0.001
	done

	# 终点位置固定颜色(不重置颜色)
	printf "\r\033[32m%$((cols - len))s%s\033[0m\n" " " "$str"
	tput cnorm
}
ls() {
	/bin/ls --color=auto
}
la() {
	/bin/ls -a --color=auto
}
ll() {
	/bin/ls -l --color=auto
}
cd() {
	_recursive_cd_selector() {
		local current_dir="$(realpath --no-symlinks "$1")"
		local options=()

		# 启用隐藏目录匹配
		shopt -s dotglob # 临时允许*匹配隐藏目录
		for dir in "$current_dir"/*/; do
			if [ -d "$dir" ] && [ ! -L "$dir" ]; then # 排除符号链接
				options+=("$dir")
				echo "$((${#options[@]}))) $(basename "$dir")"
			fi
		done
		shopt -u dotglob # 恢复默认设置

		# 添加返回上级选项(非根目录时)
		if [ "$current_dir" != "/" ]; then
			#                       echo "l] 返回上级目录"
			echo "l] ${msg_back_directory}"
		fi
		#               echo "q] 退出递归模式"
		echo "q] ${msg_exit_recursivecd}"

		# 用户输入处理
		while true; do
			#                       read -p "当前目录: $current_dir > " choice
			read -p "${msg_current_directory}: $current_dir > " choice
			case "$choice" in
			q | Q) return 0 ;;
			l | L)
				if [ "$current_dir" != "/" ]; then
					builtin cd ..
					_recursive_cd_selector "$(pwd)"
				else
					#                                       echo "已处于根目录"
					echo "${msg_at_rootdirectory}"
				fi
				return
				;;
			[0-9]*)
				if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#options[@]}" ]; then
					selected_dir="${options[$((choice - 1))]}"
					builtin cd "$selected_dir"
					_recursive_cd_selector "$(pwd)"
					return
				else
					#                                       echo "无效选择"
					echo "${err_invalid_selection}"
				fi
				;;
			*) ;;
			esac
		done
	}
	if [ $# -eq 0 ]; then
		builtin cd ~
	elif [ "$1" = "?" ]; then
		#        PS3="选择目录(输入 q 退出): "
		PS3="${msg_select_directory}: "
		# 生成非隐藏子目录列表(过滤无效的 */ 字面量)
		local subdirs=()
		for dir in */; do
			if [ -d "$dir" ] && [[ ! "$dir" =~ ^\. ]]; then # 排除隐藏目录
				subdirs+=("$dir")
			fi
		done

		# 若存在有效目录则显示选项
		if [ ${#subdirs[@]} -gt 0 ]; then
			select dir in "${subdirs[@]}"; do
				case $REPLY in
				q | Q) break ;;
				*) if [ -n "$dir" ]; then
					builtin cd "./$dir" && pwd
					break
				else
					#                            echo "无效选择"
					echo "${err_invalid_selection}"
				fi ;;
				esac
			done
		else
			# 无子目录时直接显示提示
			#            read -p "当前目录下无子目录,按任意键退出: " choice
			read -p "${msg_no_subdirectory}: " choice
			[[ "$choice" =~ [qQ] ]] && return
		fi
	elif [ "$1" = "??" ]; then
		_recursive_cd_selector "$(pwd)"
	else
		builtin cd "$@" && pwd
	fi

}

# 设置Command Prompt
export DPSHELL_LEVEL=$(( ${DPSHELL_LEVEL:-0} + 1 ))
if [[ $(whoami) = "root" ]]; then
    USER_PROMPT="($DPSHELL_LEVEL)#"
else
    USER_PROMPT="($DPSHELL_LEVEL)$"
fi
####################################################
#####################伪shell模块####################
####################################################
pseudo_shell_module() {
    # 创建临时历史文件并设置环境变量
    local HISTFILE=$(mktemp /tmp/dpshell_history.XXXXXX)
    export HISTFILE
    export HISTSIZE=1000         # 设置内存存储上限
    export HISTFILESIZE=2000      # 设置文件存储上限
    export HISTCONTROL=ignoredups # 忽略重复命令

    # 初始化历史记录
    history -c  # 清空当前会话历史
    history -w   # 写入临时文件

    start_animation
#    echo "(输入 exit 或 Ctrl+D 退出)"
    echo "${msg_enter_dpshell}"

	trap "rm -f $HISTFILE; export DPSHELL_LEVEL=$((DPSHELL_LEVEL - 1)); trap - SIGINT EXIT" EXIT SIGINT

    while IFS= read -e -r -p "dpshell${USER_PROMPT} " cmd; do
        # 处理特殊控制字符
        [[ "$cmd" == $'\014' ]] && { clear; continue; }
        [[ -z "$cmd" ]] && continue
        [[ "$cmd" == "exit" ]] && break

        # 实时写入历史文件
        history -s "$cmd"  # 立即存入内存
        history -a         # 追加到文件

        # 命令处理逻辑
        trap : SIGINT
        check_mode_module $cmd
        trap '' SIGINT
    done
#    echo "已退出: $(date "+%Y-%m-%d %H:%M:%S")"
    printf " \033[32m${msg_exit_dpshell}\033[0m $(date "+%Y-%m-%d %H:%M:%S")\n"
}
####################################################
# 主入口逻辑
if [[ $# -lt 1 ]]; then
    pseudo_shell_module
else
    check_mode_module "$@"
fi
