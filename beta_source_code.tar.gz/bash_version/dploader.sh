#!/bin/bash
# Copyright (c) 2025 Shuaibo Zhang
# shellcheck disable=SC2154,SC1090,SC1091

CONFIG_FILE="/etc/deeprotection/deeprotection.conf"
LANG_DIR="/usr/share/locale/deeprotection"

REPO_OWNER="Geekstrange"
REPO_NAME="Deeprotection"
DEB_PACKAGE_NAME="deeprotection"
DOWNLOAD_DIR="/tmp"  # 默认下载目录

# 通用 FTL 解析函数
parse_ftl() {
    local file="$1"
    while IFS= read -r line || [[ -n "$line" ]]; do
        [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue
        [[ ! "$line" =~ = ]] && continue

        local key="${line%%=*}"
        key="${key//[[:space:]]/}"  # 移除键中的空格

        local value="${line#*=}"
        if [[ "$value" =~ ^\".*\"$ ]]; then
            value="${value:1:-1}"
        fi

        value="${value//\\\"/\"}"    # 处理转义双引号
        value="${value//\\\\/\\}"    # 处理转义反斜杠
        value="${value//\\n/$'\n'}"  # 处理换行符

        declare -g "$key"="$value"
    done < "$file"
}

# 加载语言文件的函数
load_language() {
    local lang_code="$1"
    local ftl_file="${LANG_DIR}/${lang_code}.ftl"
    local default_file="${LANG_DIR}/en_US.ftl"

    if [[ -f "$ftl_file" ]]; then
        parse_ftl "$ftl_file"
        return 0
    fi

    if [[ -f "$default_file" ]]; then
        parse_ftl "$default_file"
        printf "\033[32mUsing default language.\033[0m\n"
        return 1
    fi

    printf "\033[31mError: No language files found\033[0m\n"
    return 2
}

# 获取语言代码
get_lang_code() {
    lang_code=$(awk -F= '/^[[:space:]]*language[[:space:]]*=/ {
        sub(/#.*/, "", $2);
        gsub(/[ \t]/, "", $2);
        print $2
    }' "$CONFIG_FILE")
}

# 主加载逻辑
get_lang_code
if [[ -z "$lang_code" ]]; then
    system_lang=$(echo "${LC_ALL:-${LANG:-en_US}}" | cut -d. -f1)
    if [[ -f "${LANG_DIR}/${system_lang}.ftl" ]]; then
        lang_code="$system_lang"
    else
        lang_code="en_US"
    fi
fi

# 加载语言文件
load_language "$lang_code"

# 颜色定义
RED_WD='\033[31m'       # 红色文字
YELLOW_WD='\033[33m'    # 黄色文字
GREEN_WD='\033[32m'     # 绿色文字
BLINK='\033[5m'         # 闪烁效果
RESET='\033[0m'         # 重置格式
BOLD='\033[1m'          # 加粗

call_dp() {
    $(which dp)
}

# 下载函数
start_download() {
    _cancel_download() {
        echo -ne "\r\033[K${RED_WD}${BLINK} [!]${RESET} ${BOLD}${msg_user_interrupt}${RESET}\n"
        rm -f "$DOWNLOAD_DIR/$DEB_ASSET"
        exit 1
    }
    trap _cancel_download SIGINT

    echo -n "${msg_is_downloading}..."

    if curl --silent --show-error -L -o "$DOWNLOAD_DIR/$(basename "$DEB_ASSET")" "$DEB_ASSET"; then
        echo -e "\r\033[K${GREEN_WD}${msg_download_completed}${RESET}"
        return 0
    else
        echo -e "\r\033[K${RED_WD}${err_download_failed}${RESET}"
        rm -f "$DOWNLOAD_DIR/$DEB_ASSET"
        return 1
    fi
}

# 获取GitHub Release信息

get_github_release() {
    LATEST_RELEASE=$(curl -s "https://api.github.com/repos/$REPO_OWNER/$REPO_NAME/releases/latest")
    if [ -z "$LATEST_RELEASE" ] || [ "$LATEST_RELEASE" = "null" ]; then
        echo "${err_get_version}"
        exit 1
    fi

    CLEAN_LATEST_VERSION=$(echo "$LATEST_RELEASE" | jq -r '.tag_name' | sed 's/v//g')
    if [ -z "$CLEAN_LATEST_VERSION" ]; then
        echo "${err_get_version}"
        exit 1
    fi

    # 更可靠地获取本地版本号
    if command -v dp &> /dev/null; then
        # 尝试不同方式获取版本号
        CLEAN_LOCAL_VERSION=$(dp --version 2>&1 | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+' | head -n1)

        # 如果上述方法失败，尝试备用方法
        if [ -z "$CLEAN_LOCAL_VERSION" ]; then
            CLEAN_LOCAL_VERSION=$(dpkg -l | grep 'deeprotection' | awk '{print $3}' | cut -d'-' -f1)
        fi

        # 如果仍然失败，设为0表示未安装
        if [ -z "$CLEAN_LOCAL_VERSION" ]; then
            CLEAN_LOCAL_VERSION="0"
        fi
    else
        CLEAN_LOCAL_VERSION="0"
    fi
}

# 修改版本比较逻辑 - 更健壮的方式
start_update() {
    echo "${msg_local_version}: $([ "$CLEAN_LOCAL_VERSION" = "0" ] && echo "未安装" || echo "$CLEAN_LOCAL_VERSION")"
    echo "${msg_new_version}: $CLEAN_LATEST_VERSION"

    # 更健壮的版本比较方式
    if [ "$CLEAN_LOCAL_VERSION" = "0" ] ||
       [ "$(printf "%s\n%s" "$CLEAN_LOCAL_VERSION" "$CLEAN_LATEST_VERSION" | sort -V | head -n1)" != "$CLEAN_LATEST_VERSION" ]; then
        DEB_ASSET=$(echo "$LATEST_RELEASE" | jq -r '.assets[] | select(.name | endswith(".deb")) | .browser_download_url')

        if [ -n "$DEB_ASSET" ]; then
            if start_download ; then
                if [ -f "$DOWNLOAD_DIR/$(basename "$DEB_ASSET")" ]; then
                    printf "%b" "${ask_install_now}? (\033[32my\033[0m)/(\033[31mn\033[0m)o "
                    read -r answer

                    if [[ "$answer" =~ ^[Yy]$ ]]; then
                        # 安装并检查是否成功
                        install_success=true
                        if sudo -v &>/dev/null; then
                            if ! sudo dpkg -i "$DOWNLOAD_DIR/$(basename "$DEB_ASSET")"; then
                                install_success=false
                            fi
                        else
                            if ! dpkg -i "$DOWNLOAD_DIR/$(basename "$DEB_ASSET")"; then
                                install_success=false
                            fi
                        fi

                        # 清理临时文件
                        rm -f "$DOWNLOAD_DIR/$(basename "$DEB_ASSET")"

                        if $install_success; then
                            # 验证安装
                            installed_version=$(dp --version 2>&1 | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+' | head -n1)
                            if [ "$installed_version" = "$CLEAN_LATEST_VERSION" ]; then
                                printf "${GREEN_WD}${msg_install_success}${RESET}\n"
                            else
                                echo "${err_install_fail}: $installed_version vs $CLEAN_LATEST_VERSION"
                                exit 1
                            fi
                        else
                            echo "${err_install_fail}: 安装过程中出错"
                            exit 1
                        fi
                    else
                        echo "${msg_file_path}: $DOWNLOAD_DIR/$(basename "$DEB_ASSET")"
                        exit 1
                    fi
                else
                    echo "${err_manual_download} $DEB_ASSET"
                    exit 1
                fi
            fi
        else
            printf "${err_file_notfond}" '\e]8;;https://github.com/Geekstrange/Deeprotection/issues\aReport Issues\e]8;;\a.\n'
            exit 1
        fi
    else
        echo "${msg_already_latest}"
    fi
}

# 获取更新设置值
get_update_value() {
    update_val=$(awk -F= '/^[[:space:]]*update[[:space:]]*=/ {
        sub(/#.*/, "", $2);
        gsub(/[ \t]/, "", $2);
        print $2
    }' "$CONFIG_FILE")
}

# 检查更新
check_update() {
    # 检查jq依赖
    if ! command -v jq >/dev/null 2>&1; then
        echo -e "${RED_WD}错误: 需要jq工具，请先安装 (sudo apt install jq)${RESET}"
        exit 1
    fi

    get_update_value

    if [[ -z "$update_val" ]]; then
        echo "${err_no_config}" >&2
        exit 1
    fi

    case "${update_val,,}" in
        "disable") echo "${msg_update_disabled}" && call_dp; exit 0 ;;
        "enable")
            get_github_release
            start_update
            call_dp
            exit 0
            ;;
        *)         echo "${err_unknown_status}: $update_val"; exit 2 ;;
    esac
}

# 主执行入口
check_update
